package com.google.android.gms.nearby.covid_19_app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.ArraySet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.Toast;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.github.glomadrian.materialanimatedswitch.MaterialAnimatedSwitch;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Tag;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.nio.Buffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.prefs.Preferences;

public class UserMapActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener {

    private GoogleMap mMap;

    // Play Services Var
    private static final int MY_PERMISSION_REQUEST_CODE = 7000;
    private static final int PLAY_SERVICE_RES_REQUEST = 7001;

    //StringBuilder sb = new StringBuilder();

    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;

    private static int UPDATE_INTERVAL = 5000;
    private static int FASTEST_INTERVAL = 3000;
    private static int DISPLACEMENT = 10;

    private final double radius = 0.005; // unit in km

    DatabaseReference ref;
    GeoFire geoFire;

    Button mLogout;
    Button mUserRequest;
    Button mAlter;
    MaterialAnimatedSwitch location_switch;

    Marker mCurrentLocation;

    SupportMapFragment mapFragment;

    ArrayList<String> NearbyUsersList;
    ArrayList<String> ContactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_map_activity);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Initialize Variables
        NearbyUsersList = new ArrayList<String>();
        ContactList = new ArrayList<String>();

        ref = FirebaseDatabase.getInstance().getReference("Users");
        geoFire = new GeoFire(ref);

        mUserRequest = (Button) findViewById(R.id.scan);
        mLogout = (Button) findViewById(R.id.logout);
        mAlter = (Button) findViewById(R.id.alertEmail);

        // Check switch condition (which at app lauch is disabled)
        location_switch = (MaterialAnimatedSwitch) findViewById(R.id.location_switch);
        location_switch.setOnCheckedChangeListener(new MaterialAnimatedSwitch.OnCheckedChangeListener() {
            @Override
            // Case of enabled switch = User is online and wants his/her location to be visible
            public void onCheckedChanged(boolean b) {
                if (b) {
                    startLocationUpdates();
                    displayLocation();
                    Snackbar.make(mapFragment.getView(), "Online", Snackbar.LENGTH_SHORT).show();
                } else {
                    // Case of disabled switch = User is offline and wants his/her location to be visible
                    stopLocationUpdates();
                    saveData();
                    mCurrentLocation.remove();
                    Snackbar.make(mapFragment.getView(), "Offline", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

        setUpLocation();

        // Should user press SCAN
        mUserRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanUsersAround(FirebaseAuth.getInstance().getUid());
            }
        });

        mAlter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveData();

                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{retrieveData()});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "CAUTION! You have been in contact with a COVID-19 INFECTED PERSON");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Dear user, \n\nWe hope this email finds you well.\n\n" +
                        "Recently YOU have been IN CONTACT with a USER which was just tested POSITIVE for COVID-19!" +
                        "\n\nAs a result, you are kindly requested to please take the required precautions so that you, and your loved ones, can be SAFE." +
                        "\n\nShould you need assistance or have any questions please do not hesitate to contact us at any time " +
                        "by email on COVID.19@gmail, or on +961 00 000 000." +
                        "\n\nBest regards, \n\nCOVID-19 support team.");
                emailIntent.setType("message/rfc822");
                startActivity(Intent.createChooser(emailIntent, "Choose email Client..."));
            }
        });

        // Should User press Logout
        mLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users Online");
                GeoFire geoFire = new GeoFire(ref);
                geoFire.removeLocation(FirebaseAuth.getInstance().getCurrentUser().getUid());
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(UserMapActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                return;

            }
        });

    }

    private void saveData() {

       // Remove possible email duplicates
       Set<String> set = new HashSet<>(NearbyUsersList);
       NearbyUsersList.clear();
       NearbyUsersList.addAll(set);

       StringBuilder sb = new StringBuilder();

       for(int i=0; i<NearbyUsersList.size(); i++)
           sb.append(NearbyUsersList.get(i)+ "\n");

       String date = (new SimpleDateFormat("dd/MM/YYYY", Locale.getDefault()).format(new Date()) +".txt");
       /*
       File info = new File(date);
        String str = "";
        for(int i=0; i<NearbyUsersList.size(); i++)
            str += NearbyUsersList.get(i) + " ";
        try{
            FileOutputStream fileOutputStream = openFileOutput(date, MODE_PRIVATE);
            fileOutputStream.write(str.getBytes());
            fileOutputStream.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
        }

        */

        try {
            File myFile = new File(Environment.getExternalStorageDirectory().getPath()+date);
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.write(sb.toString());
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Toast.makeText(this, "Data saved Successfully... to" + date, Toast.LENGTH_SHORT).show();
    }

    private String retrieveData(){
        StringBuilder sb1 = new StringBuilder();
        Set<String> set = new HashSet<>(NearbyUsersList);
        NearbyUsersList.clear();
        NearbyUsersList.addAll(set);
        for(int i=0; i<NearbyUsersList.size(); i++)
            sb1.append(NearbyUsersList.get(i) + ", ");

        return sb1.toString();
    }

    /*private String retrieveData(){

        String day1 = new SimpleDateFormat("dd/MM/YYYY", Locale.getDefault()).format(new Date()) +".txt";

        //Divide Date to day month and year
        int prt1 = Integer.parseInt(day1.substring(0,2));
        int prt2 = Integer.parseInt(day1.substring(3,5));
        int prt3 = Integer.parseInt(day1.substring(6));

        int count = 0;

        while(count <14) {
            while (prt1 > 0 && count<14) {
                if(prt1<=10){
                    String datee = "0"+ (--prt1) + "/" + prt2 + "/" + prt3 + ".txt";

                    String contents="";

                    File myFile = new File(Environment.getExternalStorageDirectory().getPath()+datee);
                    if(!myFile.exists()){

                    }

                    try {
                        BufferedReader br = new BufferedReader(new FileReader(myFile));
                        int c;
                        while ((c = br.read()) != -1) {
                            contents=contents+(char)c;
                            ContactList.add(contents);
                        }

                    }
                    catch (IOException e) {
                        return "";
                    }
                    count++;
                }
                else {
                    String datee = (--prt1) + "/" + prt2 + "/" + prt3 + ".txt";
                    String contents="";

                    File myFile = new File(Environment.getExternalStorageDirectory().getPath()+datee);
                    if(!myFile.exists()){

                    }
                    try {
                        BufferedReader br = new BufferedReader(new FileReader(myFile));
                        int c;
                        while ((c = br.read()) != -1) {
                            contents=contents+(char)c;
                            ContactList.add(contents);
                        }
                    } catch (IOException e) {
                        //You'll need to add proper error handling here
                        return "";
                    }
                    count++;
                }
            }
            if (prt1 == 0) {
                String datee = (prt1=31) + "/" + (--prt2) + "/" + prt3 + ".txt";
                String contents="";

                File myFile = new File(Environment.getExternalStorageDirectory().getPath()+datee);
                if(!myFile.exists()){
                }
                try {
                    BufferedReader br = new BufferedReader(new FileReader(myFile));
                    int c;
                    while ((c = br.read()) != -1) {
                        contents=contents+(char)c;
                        ContactList.add(contents);
                    }

                }
                catch (IOException e) {
                    //You'll need to add proper error handling here
                    return "";
                }
                count++;
            }
        }
        StringBuilder sb1 = new StringBuilder();
        Set<String> set = new HashSet<>(ContactList);
        ContactList.clear();
        ContactList.addAll(set);
        for(int i=0; i<ContactList.size(); i++)
            sb1.append(ContactList.get(i) + " ");

        return sb1.toString();
    }*/

    private void scanUsersAround(String uid) {

        if (mCurrentLocation.isVisible())
            mCurrentLocation.remove();

        mCurrentLocation = mMap.addMarker(new MarkerOptions().title("Scanning from here").snippet("")
                .position(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()))
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        mUserRequest.setText("Scanning nearby users...");
        //findUsers();
        //listUsersAround();
        findNearbyUsers();
    }

    private void findNearbyUsers() {
        //DatabaseReference ref = FirebaseDatabase.getInstance().getReference("GeoFire/path");
        //GeoFire geoFire = new GeoFire(ref);

        final double latitude = mLastLocation.getLatitude();
        final double longitude = mLastLocation.getLongitude();

        GeoQuery geoQuery = geoFire.queryAtLocation(new GeoLocation(latitude,longitude),radius);

        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {
                DatabaseReference nearby = FirebaseDatabase.getInstance().getReference("Users").child(key);
                nearby.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        UserA nearbyUser = dataSnapshot.getValue(UserA.class);
                        String str = nearbyUser.getEmail() + "";
                        NearbyUsersList.add(str);

                        Snackbar.make(mapFragment.getView(), str, Snackbar.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onKeyExited(String key) {

            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public void onGeoQueryReady() {

            }

            @Override
            public void onGeoQueryError(DatabaseError error) {

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (checkPlayServices()) {
                        //buildGoogleApiClient();
                        //Google API
                        mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this)
                                .addOnConnectionFailedListener(this)
                                .addApi(LocationServices.API)
                                .build();
                        mGoogleApiClient.connect();

                        RequestLocation();
                        if (location_switch.isChecked())
                            displayLocation();
                    }
                }
        }
    }

    private void setUpLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSION_REQUEST_CODE);
        } else {
            if (checkPlayServices()) {
                //buildGoogleApiClient();
                //Google API
                mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this)
                        .addOnConnectionFailedListener(this)
                        .addApi(LocationServices.API)
                        .build();
                mGoogleApiClient.connect();

                RequestLocation();
                if (location_switch.isChecked())
                    displayLocation();
            }
        }

    }

    private void RequestLocation() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setSmallestDisplacement(DISPLACEMENT);
    }

    private boolean checkPlayServices() {
        int requestedCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (requestedCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(requestedCode))
                GooglePlayServicesUtil.getErrorDialog(requestedCode, this, PLAY_SERVICE_RES_REQUEST).show();
            else {
                Toast.makeText(this, "Device not supported...", Toast.LENGTH_SHORT).show();
                finish();
            }
            return false;

        }
        return true;
    }

    private void stopLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users Online");
        GeoFire geoFire = new GeoFire(ref);
        geoFire.removeLocation(FirebaseAuth.getInstance().getCurrentUser().getUid());
    }

    private void displayLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            //DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users Online");
            //GeoFire geoFire = new GeoFire(ref);

            ref = FirebaseDatabase.getInstance().getReference("Users Online");
            geoFire = new GeoFire(ref);


            if (location_switch.isChecked()) {

                // save location lat and lon
                final double latitude = mLastLocation.getLatitude();
                final double longitude = mLastLocation.getLongitude();

                // Save location to firebase

                geoFire.setLocation(FirebaseAuth.getInstance().getCurrentUser().getUid(), new GeoLocation(latitude, longitude),
                        new GeoFire.CompletionListener() {
                            @Override
                            public void onComplete(String key, DatabaseError error) {
                                if (mCurrentLocation != null)
                                    mCurrentLocation.remove();

                                mCurrentLocation = mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory
                                        .fromResource(R.drawable.userphoto))
                                        .position(new LatLng(latitude, longitude))
                                        .title("Current Location"));

                                // set camera to current position
                                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 15.0f));
                                rotateMaker(mCurrentLocation, -360, mMap);
                            }
                        });
            }
        } else {
            Log.d("ERROR", "Location not saved");
        }
    }

    private void rotateMaker(final Marker mCurrentLocation, final int i, GoogleMap mMap) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final float startRotation = mCurrentLocation.getRotation();
        final long duration = 1500;

        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed / duration);
                float rot = t * i + (1 - t) * startRotation;
                mCurrentLocation.setRotation(-rot > 180 ? rot / 2 : rot);
                if (t < 1.0) {
                    handler.postDelayed(this, 16);
                }
            }
        });
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        displayLocation();

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        displayLocation();
        startLocationUpdates();

    }

    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}