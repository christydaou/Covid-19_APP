package com.google.android.gms.nearby.covid_19_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;

import dmax.dialog.SpotsDialog;

public class MainActivity extends AppCompatActivity {

    RelativeLayout main_layout;

    Button mLogin;
    Button mRegister;

    FirebaseAuth mAuth;
    FirebaseDatabase mDb;
    DatabaseReference users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize my FireBase
        mAuth = FirebaseAuth.getInstance();
        mDb = FirebaseDatabase.getInstance();
        users = mDb.getReference("Users");

        // Initialize my Buttons and Layout
        mLogin = (Button) findViewById(R.id.login);
        mRegister = (Button) findViewById(R.id.register);
        main_layout = (RelativeLayout) findViewById(R.id.main_layout);

        // What Happens when Buttons are pressed
        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRegistrationPage();
            }
        });

        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLoginPage();
            }
        });

    }

    private void showLoginPage() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Login");
        dialog.setMessage("Use email address to login...");

        LayoutInflater inflater = LayoutInflater.from(this);
        View activity_login = inflater.inflate(R.layout.activity_login, null);

        final MaterialEditText mEmail = activity_login.findViewById(R.id.email);
        final MaterialEditText mPassword = activity_login.findViewById(R.id.password);

        dialog.setView(activity_login);

        dialog.setPositiveButton("Login", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                // Setting the disabled
                mLogin.setEnabled(false);


                if (TextUtils.isEmpty(mEmail.getText().toString())) {
                    Snackbar.make(main_layout, "Missing email address...", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(mPassword.getText().toString())) {
                    Snackbar.make(main_layout, "Missing password...", Snackbar.LENGTH_SHORT).show();
                    return;
                }

                // Waiting dialog mainly aesthetic to know that our login click was recorded by the app
                final SpotsDialog waitingDialog = new SpotsDialog(MainActivity.this);
                waitingDialog.show();

                //Login user into the app
                mAuth.signInWithEmailAndPassword(mEmail.getText().toString(), mPassword.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                waitingDialog.dismiss();
                                Intent intent = new Intent(MainActivity.this, UserMapActivity.class);
                                startActivity(intent);
                                finish();
                                return;
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        waitingDialog.dismiss();
                        Snackbar.make(main_layout, "Login failed...", Snackbar.LENGTH_SHORT).show();

                        mLogin.setEnabled(true);
                    }
                });
            }
        });

        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void showRegistrationPage() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Register");
        dialog.setMessage("Use email address to register...");

        LayoutInflater inflater = LayoutInflater.from(this);
        View activity_registration = inflater.inflate(R.layout.activity_registration, null);

        final MaterialEditText mEmail = activity_registration.findViewById(R.id.email);
        final MaterialEditText mPassword = activity_registration.findViewById(R.id.password);
        final MaterialEditText mPhoneNumber = activity_registration.findViewById(R.id.phoneNumber);
        final MaterialEditText mName = activity_registration.findViewById(R.id.name);
        final MaterialEditText mGender = activity_registration.findViewById(R.id.gender);

        dialog.setView(activity_registration);

        // Creating Register and Cancel Registration Buttons
        dialog.setPositiveButton("Register", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                // Validate inputs for creating account
                if (TextUtils.isEmpty(mEmail.getText().toString())) {
                    Snackbar.make(main_layout, "Missing email address...", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(mPassword.getText().toString())) {
                    Snackbar.make(main_layout, "Missing password...", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(mPhoneNumber.getText().toString())) {
                    Snackbar.make(main_layout, "Missing phone number...", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(mName.getText().toString())) {
                    Snackbar.make(main_layout, "Missing name...", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(mGender.getText().toString())) {
                    Snackbar.make(main_layout, "Missing gender...", Snackbar.LENGTH_SHORT).show();
                    return;
                }

                // Register User into our FirebaseDatabase
                mAuth.createUserWithEmailAndPassword(mEmail.getText().toString(), mPassword.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                UserA userA = new UserA();


                                userA.setEmail(mEmail.getText().toString());
                                userA.setPassword(mPassword.getText().toString());
                                userA.setName(mName.getText().toString());
                                userA.setPhoneNumber(mPhoneNumber.getText().toString());
                                userA.setGender(mGender.getText().toString());

                                users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userA)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Snackbar.make(main_layout, "Registration Successful...", Snackbar.LENGTH_SHORT).show();
                                                Post post = new Post(FirebaseAuth.getInstance().getCurrentUser().getUid(),
                                                        mName.getText().toString(), mEmail.getText().toString());
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Snackbar.make(main_layout, "Registration not Successful...", Snackbar.LENGTH_SHORT).show();
                                    }
                                });

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(main_layout, "Registration not Successful...", Snackbar.LENGTH_SHORT).show();
                    }
                });
            }
        });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        dialog.show();

    }
}

