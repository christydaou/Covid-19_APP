package com.google.android.gms.nearby.covid_19_app;

import java.util.HashMap;
import java.util.Map;

//@IgnoreExtraProperties
public class Post {

    public String uid;
    public String name;
    public String email;
    public int starCount = 0;
    public Map<String, Boolean> stars = new HashMap<>();

    public Post(String key) {
        // Default constructor required for calls to DataSnapshot.getValue(Post.class)
    }

    public Post(String uid, String name, String email) {
        this.uid = uid;
        this.name = name;
        this.email = email;

    }

    //@Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("uid", uid);
        result.put("name", name);
        result.put("email", email);
        result.put("starCount", starCount);
        result.put("stars", stars);

        return result;
    }

}